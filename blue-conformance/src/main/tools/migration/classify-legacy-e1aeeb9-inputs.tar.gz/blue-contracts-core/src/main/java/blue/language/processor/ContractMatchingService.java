package blue.language.processor;

import blue.language.api.BlueCachePolicy;
import blue.language.identity.BlueIds;
import blue.language.runtime.LanguageRuntimeAccess;
import blue.language.provider.NodeProvider;
import blue.language.model.Node;
import blue.language.snapshot.FrozenNode;
import blue.language.matching.FrozenTypeMatcher;

import java.util.Objects;

/**
 * Shared, bounded matcher facade for contract-level event patterns.
 *
 * <p>Structural matching and verified declared-type lineage use separate
 * caches under one {@link BlueCachePolicy}. A service without a
 * {@link LanguageRuntimeAccess} context can match exact inline values but
 * fails closed when provider-backed ancestry is required.</p>
 */
public final class ContractMatchingService {

    private final LanguageRuntimeAccess languageRuntime;
    private final BlueCachePolicy cachePolicy;
    private final FrozenTypeMatcher matcher;
    private final DeclaredTypeLineageMatcher declaredTypeLineageMatcher;

    /**
     * Creates a bounded matcher with no provider-backed type ancestry.
     */
    public ContractMatchingService() {
        this(null);
    }

    /**
     * Creates a bounded matcher using the supplied Language runtime context.
     *
     * @param languageRuntime resolution context, or {@code null} to disable
     *        provider-backed ancestry
     */
    public ContractMatchingService(
            LanguageRuntimeAccess languageRuntime) {
        this.languageRuntime = languageRuntime;
        this.cachePolicy = languageRuntime != null
                ? languageRuntime.cachePolicy()
                : BlueCachePolicy.boundedDefaults();
        this.matcher = new FrozenTypeMatcher(languageRuntime);
        this.declaredTypeLineageMatcher = new DeclaredTypeLineageMatcher(
                languageRuntime != null
                        ? languageRuntime.getNodeProvider()
                        : null,
                cachePolicy);
    }

    /**
     * Creates a matcher for an immutable processor configuration without
     * constructing an aggregate facade.
     *
     * @param nodeProvider verified provider used for declared-type ancestry
     * @param cachePolicy bounds for matcher-owned caches
     */
    ContractMatchingService(
            NodeProvider nodeProvider,
            BlueCachePolicy cachePolicy) {
        this.languageRuntime = null;
        this.cachePolicy = Objects.requireNonNull(
                cachePolicy, "cachePolicy");
        this.matcher = FrozenTypeMatcher.withoutRuntime(this.cachePolicy);
        this.declaredTypeLineageMatcher = new DeclaredTypeLineageMatcher(
                nodeProvider,
                this.cachePolicy);
    }

    LanguageRuntimeAccess blue() {
        return languageRuntime;
    }

    boolean eventDeclaredTypeIsSameOrDescendantOf(Node eventType, Node expectedType) {
        return declaredTypeLineageMatcher.isSameOrDescendant(eventType, expectedType);
    }

    int declaredTypeLineageCacheSize() {
        return declaredTypeLineageMatcher.cacheSize();
    }

    BlueCachePolicy cachePolicy() {
        return cachePolicy;
    }

    int matcherCacheSize() {
        return matcher.cacheEntryCount();
    }

    int cacheEntryCount() {
        return matcher.cacheEntryCount() + declaredTypeLineageMatcher.cacheSize();
    }

    long cacheWeightBytes() {
        long matcherWeight = matcher.cacheWeightBytes();
        long lineageWeight = declaredTypeLineageMatcher.cacheWeightBytes();
        return Long.MAX_VALUE - matcherWeight < lineageWeight
                ? Long.MAX_VALUE
                : matcherWeight + lineageWeight;
    }

    /** Releases matching, reference-resolution, and declared-lineage caches. */
    public void clearCaches() {
        matcher.clearCaches();
        declaredTypeLineageMatcher.clearCaches();
    }

    /**
     * Matches immutable values; a null pattern is the unconditional pattern.
     *
     * @param event frozen event value, possibly {@code null}
     * @param pattern frozen pattern, or {@code null} for an unconditional match
     * @return whether the event satisfies the pattern
     */
    public boolean matches(FrozenNode event, FrozenNode pattern) {
        if (pattern == null) {
            return true;
        }
        return matcher.matchesType(event, pattern);
    }

    /**
     * Matches an exact value whose canonical identity was already established
     * by the owning admission boundary.
     *
     * <p>A pure-reference pattern denotes that exact value identity. Other
     * patterns retain the ordinary structural/type matching behavior. Keeping
     * the identity as explicit evidence avoids rehashing a resolver-completed
     * graph while preserving exact-reference event semantics.</p>
     */
    boolean matchesExactValue(
            FrozenNode value,
            String valueBlueId,
            FrozenNode pattern) {
        if (pattern == null) {
            return true;
        }
        if (value == null) {
            return false;
        }
        String exactBlueId = BlueIds.requireBlueIdOrCyclicMember(
                valueBlueId, "exactValueBlueId");
        if (pattern.isReferenceOnly()
                && exactBlueId.equals(pattern.getReferenceBlueId())) {
            return true;
        }
        return matcher.matchesType(value, pattern);
    }

    /**
     * Defensively freezes mutable values before matching. A non-null pattern
     * never matches a null event.
     *
     * @param event mutable event value, possibly {@code null}
     * @param pattern mutable pattern, or {@code null} for an unconditional match
     * @return whether the event satisfies the pattern
     */
    public boolean matches(Node event, Node pattern) {
        if (pattern == null) {
            return true;
        }
        if (event == null) {
            return false;
        }
        return matches(FrozenNode.fromResolvedNode(event), FrozenNode.fromResolvedNode(pattern));
    }

}
