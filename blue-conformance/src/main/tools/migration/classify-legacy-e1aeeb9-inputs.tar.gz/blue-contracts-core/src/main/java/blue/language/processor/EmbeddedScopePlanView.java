package blue.language.processor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Public read-only projection of one effective Process Embedded scope plan.
 *
 * <p>The view exposes declaration provenance and concrete stable-key
 * occurrences without exposing mutable document nodes or the processor's
 * invocation-local plan implementation. It is inspection data only: creating
 * or reading the value executes no contract and consumes no Contracts gas.</p>
 */
public final class EmbeddedScopePlanView {

    /** Identifies the declaration form that produced a concrete child path. */
    public enum Origin {
        /** The child was named directly by {@code Process Embedded.paths}. */
        EXPLICIT,
        /** The child is a direct stable-key collection member. */
        COLLECTION_MEMBER
    }

    /** Successful projection state of one collection declaration. */
    public enum CollectionState {
        /** The declared path was absent and contributed zero occurrences. */
        ABSENT_ZERO_OCCURRENCES,
        /** The declared path selected a present, verified object collection. */
        PRESENT_COLLECTION
    }

    private final String scopePath;
    private final List<String> explicitDeclarationPaths;
    private final List<String> collectionDeclarationPaths;
    private final Map<String, List<String>>
            collectionMemberKeysByDeclaration;
    private final Map<String, CollectionState> collectionStatesByDeclaration;
    private final List<String> concreteChildPaths;
    private final Map<String, Origin> originsByConcretePath;

    EmbeddedScopePlanView(
            String scopePath,
            List<String> explicitDeclarationPaths,
            List<String> collectionDeclarationPaths,
            Map<String, List<String>> collectionMemberKeysByDeclaration,
            Map<String, CollectionState> collectionStatesByDeclaration,
            List<String> concreteChildPaths,
            Map<String, Origin> originsByConcretePath) {
        this.scopePath = Objects.requireNonNull(scopePath, "scopePath");
        this.explicitDeclarationPaths = immutableList(
                explicitDeclarationPaths, "explicitDeclarationPaths");
        this.collectionDeclarationPaths = immutableList(
                collectionDeclarationPaths, "collectionDeclarationPaths");
        this.collectionMemberKeysByDeclaration = immutableLists(
                collectionMemberKeysByDeclaration,
                "collectionMemberKeysByDeclaration");
        this.collectionStatesByDeclaration = immutableMap(
                collectionStatesByDeclaration,
                "collectionStatesByDeclaration");
        java.util.LinkedHashSet<String> declarations =
                new java.util.LinkedHashSet<>(
                        this.collectionDeclarationPaths);
        if (!declarations.equals(
                this.collectionMemberKeysByDeclaration.keySet())
                || !declarations.equals(
                        this.collectionStatesByDeclaration.keySet())) {
            throw new IllegalArgumentException(
                    "Collection projections must match collection declarations");
        }
        this.concreteChildPaths = immutableList(
                concreteChildPaths, "concreteChildPaths");
        this.originsByConcretePath = Collections.unmodifiableMap(
                new LinkedHashMap<>(Objects.requireNonNull(
                        originsByConcretePath,
                        "originsByConcretePath")));
        if (!this.originsByConcretePath.keySet().equals(
                new java.util.LinkedHashSet<>(this.concreteChildPaths))) {
            throw new IllegalArgumentException(
                    "Concrete paths and origin keys must be identical");
        }
    }

    static EmbeddedScopePlanView from(EmbeddedScopePlan plan) {
        Objects.requireNonNull(plan, "plan");
        Map<String, Origin> origins = new LinkedHashMap<>();
        for (Map.Entry<String, EmbeddedPathOrigin> entry
                : plan.concretePathOrigins().entrySet()) {
            origins.put(
                    entry.getKey(),
                    entry.getValue() == EmbeddedPathOrigin.EXPLICIT
                            ? Origin.EXPLICIT
                            : Origin.COLLECTION_MEMBER);
        }
        Map<String, CollectionState> states = new LinkedHashMap<>();
        for (Map.Entry<String, EmbeddedCollectionState> entry
                : plan.collectionStatesByDeclaration().entrySet()) {
            states.put(
                    entry.getKey(),
                    entry.getValue()
                            == EmbeddedCollectionState.PRESENT_COLLECTION
                            ? CollectionState.PRESENT_COLLECTION
                            : CollectionState.ABSENT_ZERO_OCCURRENCES);
        }
        return new EmbeddedScopePlanView(
                plan.scopePath(),
                plan.explicitDeclarationPaths(),
                plan.collectionDeclarationPaths(),
                plan.collectionMemberKeysByDeclaration(),
                states,
                plan.concreteChildPaths(),
                origins);
    }

    static EmbeddedScopePlanView empty(String scopePath) {
        return new EmbeddedScopePlanView(
                scopePath,
                Collections.<String>emptyList(),
                Collections.<String>emptyList(),
                Collections.<String, List<String>>emptyMap(),
                Collections.<String, CollectionState>emptyMap(),
                Collections.<String>emptyList(),
                Collections.<String, Origin>emptyMap());
    }

    /**
     * Returns the absolute path of the declaring scope.
     *
     * @return normalized absolute scope path
     */
    public String scopePath() {
        return scopePath;
    }

    /**
     * Returns exact child declarations in effective list order.
     *
     * @return immutable explicit declaration list
     */
    public List<String> explicitDeclarationPaths() {
        return explicitDeclarationPaths;
    }

    /**
     * Returns collection declarations in effective list order.
     *
     * @return immutable collection declaration list
     */
    public List<String> collectionDeclarationPaths() {
        return collectionDeclarationPaths;
    }

    /**
     * Returns canonical direct member keys for every collection declaration.
     *
     * @return immutable declaration-to-member-key map
     */
    public Map<String, List<String>>
    collectionMemberKeysByDeclaration() {
        return collectionMemberKeysByDeclaration;
    }

    /**
     * Returns whether every collection declaration was absent or present.
     *
     * <p>Both an absent collection and a present empty collection have no
     * member keys; this map preserves that semantic distinction.</p>
     *
     * @return immutable declaration-to-state map
     */
    public Map<String, CollectionState> collectionStatesByDeclaration() {
        return collectionStatesByDeclaration;
    }

    /**
     * Returns combined absolute concrete child paths in canonical order.
     *
     * @return immutable concrete child path list
     */
    public List<String> concreteChildPaths() {
        return concreteChildPaths;
    }

    /**
     * Returns declaration origin for every concrete child path.
     *
     * @return immutable concrete-path origin map
     */
    public Map<String, Origin> originsByConcretePath() {
        return originsByConcretePath;
    }

    private static List<String> immutableList(
            List<String> source,
            String label) {
        Objects.requireNonNull(source, label);
        List<String> copy = new ArrayList<>(source.size());
        for (String value : source) {
            copy.add(Objects.requireNonNull(value, label + " value"));
        }
        return Collections.unmodifiableList(copy);
    }

    private static Map<String, List<String>> immutableLists(
            Map<String, List<String>> source,
            String label) {
        Objects.requireNonNull(source, label);
        Map<String, List<String>> copy = new LinkedHashMap<>();
        for (Map.Entry<String, List<String>> entry : source.entrySet()) {
            copy.put(
                    Objects.requireNonNull(entry.getKey(), label + " key"),
                    immutableList(entry.getValue(), label + " value"));
        }
        return Collections.unmodifiableMap(copy);
    }

    private static <T> Map<String, T> immutableMap(
            Map<String, T> source,
            String label) {
        Objects.requireNonNull(source, label);
        Map<String, T> copy = new LinkedHashMap<>();
        for (Map.Entry<String, T> entry : source.entrySet()) {
            copy.put(
                    Objects.requireNonNull(entry.getKey(), label + " key"),
                    Objects.requireNonNull(entry.getValue(), label + " value"));
        }
        return Collections.unmodifiableMap(copy);
    }
}
