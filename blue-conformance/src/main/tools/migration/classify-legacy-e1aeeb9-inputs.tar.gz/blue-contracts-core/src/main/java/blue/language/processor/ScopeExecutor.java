package blue.language.processor;

import blue.language.model.Node;
import blue.language.processor.model.JsonPatch;
import blue.language.processor.model.ChannelContract;
import blue.language.processor.model.DocumentUpdateChannel;
import blue.language.processor.model.EmbeddedCollectionEventChannel;
import blue.language.processor.model.EmbeddedNodeChannel;
import blue.language.processor.model.LifecycleChannel;
import blue.language.processor.model.TriggeredEventChannel;
import blue.language.processor.util.ProcessorContractConstants;
import blue.language.snapshot.FrozenNode;
import blue.language.model.wire.JsonPointer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/**
 * Handles scope traversal, embedded processing, cascades, and lifecycle delivery.
 *
 * <p>Each {@link ProcessorInvocationState} owns a single instance which
 * orchestrates the five-phase algorithm for a scope. Consolidating the logic
 * here keeps {@code ProcessorEngine} primarily focused on composition.</p>
 */
final class ScopeExecutor {

    private final ProcessorInvocationServices owner;
    private final ProcessorInvocationState execution;
    private final DocumentProcessingRuntime runtime;
    private final ChannelRunner channelRunner;
    private final ScopeParticipationRegistry participation;
    private final ScopeFrameFactory frameFactory;
    private final ScopePropagationChain propagationChain;
    private final ScopeLifecycleExecutor lifecycleExecutor;
    private final ExternalCandidateProjector candidateProjector;
    private final ScopeMutationExecutor mutationExecutor;

    ScopeExecutor(ProcessorInvocationServices owner,
                  ProcessorInvocationState execution,
                  DocumentProcessingRuntime runtime,
                  Map<String, ContractBundle> bundles,
                  ChannelRunner channelRunner) {
        this(owner, execution, runtime, bundles, channelRunner, null);
    }

    ScopeExecutor(ProcessorInvocationServices owner,
                  ProcessorInvocationState execution,
                  DocumentProcessingRuntime runtime,
                  Map<String, ContractBundle> bundles,
                  ChannelRunner channelRunner,
                  final ManagedDocumentStepContinuation continuationHook) {
        this.owner = Objects.requireNonNull(owner, "owner");
        this.execution = Objects.requireNonNull(execution, "execution");
        this.runtime = Objects.requireNonNull(runtime, "runtime");
        this.channelRunner = Objects.requireNonNull(channelRunner, "channelRunner");
        this.participation = new ScopeParticipationRegistry(
                Objects.requireNonNull(bundles, "bundles"));
        this.frameFactory = new ScopeFrameFactory(
                owner, execution, runtime, participation);
        ScopeHandlerDispatcher handlerDispatcher =
                new ScopeHandlerDispatcher(owner, execution, runtime);
        this.propagationChain = new ScopePropagationChain(
                owner,
                execution,
                runtime,
                participation,
                frameFactory,
                handlerDispatcher);
        this.lifecycleExecutor = new ScopeLifecycleExecutor(
                execution,
                runtime,
                handlerDispatcher,
                propagationChain);
        this.candidateProjector = new ExternalCandidateProjector(
                owner, execution, runtime);
        DocumentUpdateRouter updateRouter = new DocumentUpdateRouter(
                owner,
                execution,
                runtime,
                participation,
                frameFactory,
                propagationChain,
                channelRunner);
        PatchPreflight patchPreflight = new PatchPreflight(owner, runtime);
        this.mutationExecutor = continuationHook == null
                ? new ScopeMutationExecutor(
                        owner,
                        execution,
                        runtime,
                        patchPreflight,
                        updateRouter)
                : new ScopeMutationExecutor(
                        owner,
                        execution,
                        runtime,
                        patchPreflight,
                        new ScopeMutationExecutor.UpdateContinuation() {
                            @Override
                            public FrozenDispatchContext freezeBeforePatch(
                                    String scopePath,
                                    ContractBundle bundle) {
                                /*
                                 * Refresh only at the next authored patch
                                 * boundary. The prior transition has already
                                 * committed, so this is the live surface whose
                                 * current delivery must now be frozen. Closure
                                 * continuation output never replaces or
                                 * invalidates this runtime's document.
                                 */
                                ContractBundle live = frameFactory.refresh(
                                        scopePath, true, false);
                                return FrozenDispatchContext.capture(
                                        participation,
                                        scopePath,
                                        live != null ? live : bundle);
                            }

                            @Override
                            public void continueAfterPatch(
                                    String scopePath,
                                    ContractBundle bundle,
                                    FrozenJsonPatch patch,
                                    List<DocumentUpdateData> updates,
                                    FrozenDispatchContext dispatchContext) {
                                FrozenNode selectedBeforeContinuation =
                                        FrozenNode.fromResolvedNode(
                                                runtime.document().clone());
                                continuationHook.afterPatch(
                                        scopePath,
                                        runtime.document(),
                                        patch,
                                        updateOccurrences(
                                                updates,
                                                dispatchContext));
                                runtime.synchronizeSelectedDocumentAfterContinuation(
                                        selectedBeforeContinuation);
                            }
                        });
    }

    void initializeScope(String scopePath, boolean chargeScopeEntry) {
        initializeScope(scopePath, chargeScopeEntry, true);
    }

    /**
     * Opens only the selected managed document's Root scope.
     *
     * <p>This deliberately does not walk {@code Process Embedded}. Managed
     * child documents are separate closure execution units and are opened by
     * their own invocation state.</p>
     */
    ContractBundle preflightIsolatedManagedRoot(
            ManagedDocumentStepRequest request) {
        runtime.setScopeEmbeddedDepth(JsonPointer.ROOT, 0);
        runtime.chargeScopeEntry(JsonPointer.ROOT);
        preflightSelectedHeaders(JsonPointer.ROOT);
        String normalizedScope = JsonPointer.ROOT;
        FrozenNode selected = runtime.selectedFrozenAt(normalizedScope);
        FrozenNode resolved = runtime.resolvedFrozenAt(normalizedScope);
        if (!frameFactory.isParticipatingScope(normalizedScope, selected)
                || !frameFactory.isParticipatingScope(
                        normalizedScope, resolved)) {
            throw new InvalidExecutionEvidenceException(
                    "Participating managed Root is absent or not an object");
        }
        if (runtime.hasTerminationMarker(normalizedScope)) {
            throw new InvalidExecutionEvidenceException(
                    "Participating managed Root is directly terminated");
        }
        return frameFactory.refreshManagedRoot(
                normalizedScope,
                request.resolutionOverlay()
                        .expectedManagedBlueIdsByPath());
    }

    /** Executes one already-selected Root work occurrence without a FIFO drain. */
    void executeIsolatedManagedRootWork(
            ManagedDocumentStepRequest request) {
        executeIsolatedManagedRootWork(request, null);
    }

    /** Executes one Root work occurrence with an optional frozen route. */
    void executeIsolatedManagedRootWork(
            ManagedDocumentStepRequest request,
            ManagedDocumentStepRoute selectedRoute) {
        Objects.requireNonNull(request, "request");
        ManagedDocumentWorkKind kind = request.workKind();
        String channelKey = request.channelKey();
        Objects.requireNonNull(kind, "kind");
        ContractBundle liveBundle = preflightIsolatedManagedRoot(request);
        if (kind == ManagedDocumentWorkKind.INITIALIZATION) {
            /*
             * Closure initialization freezes the member and lifecycle
             * contract here. Lifecycle delivery and the marker batch are
             * distinct orchestrator-owned boundaries.
             */
            runtime.chargeInitialization(JsonPointer.ROOT);
            return;
        }
        if (kind == ManagedDocumentWorkKind.CONTAINING_REFERENCE_UPDATE) {
            mutationExecutor.execute(
                    JsonPointer.ROOT,
                    liveBundle,
                    Collections.singletonList(
                            PatchInput.frozen(request.processorPatch())),
                    false,
                    null);
            return;
        }

        ContractBundle dispatchBundle = selectedRoute == null
                ? liveBundle
                : requireFrozenDispatchBundle(request, selectedRoute);
        Node exactPayload = selectedRoute == null
                ? request.exactPayload()
                : selectedRoute.exactPayload();
        Objects.requireNonNull(exactPayload, "exactPayload");
        String matchingEventBlueId = selectedRoute == null
                ? request.matchingEventBlueId()
                : selectedRoute.matchingEventBlueId();
        ContractBundle.ChannelBinding channel = requireStepChannel(
                dispatchBundle, channelKey);
        requireStepChannelRole(kind, channel);
        if (kind == ManagedDocumentWorkKind.TRIGGERED_EVENT) {
            runtime.chargeTriggeredDelivery();
        } else if (kind == ManagedDocumentWorkKind.EMBEDDED_EVENT) {
            runtime.chargeBridge(exactPayload);
        } else if (kind == ManagedDocumentWorkKind.LIFECYCLE) {
            runtime.chargeLifecycleDelivery();
        }
        if (kind == ManagedDocumentWorkKind.EMBEDDED_EVENT) {
            Node occurrenceEvent = selectedRoute == null
                    ? request.occurrenceEvent()
                    : selectedRoute.occurrenceEvent();
            channelRunner.runHandlers(
                    JsonPointer.ROOT,
                    dispatchBundle,
                    channel.key(),
                    exactPayload,
                    occurrenceEvent,
                    matchingEventBlueId);
        } else {
            channelRunner.runHandlers(
                    JsonPointer.ROOT,
                    dispatchBundle,
                    channel.key(),
                    exactPayload,
                    matchingEventBlueId,
                    kind == ManagedDocumentWorkKind.LIFECYCLE);
        }
    }

    private ContractBundle requireFrozenDispatchBundle(
            ManagedDocumentStepRequest request,
            ManagedDocumentStepRoute selectedRoute) {
        if (request.workKind() != selectedRoute.workKind()
                || !Objects.equals(
                        request.channelKey(),
                        selectedRoute.channelKey())
                || !Objects.equals(
                        request.matchingEventBlueId(),
                        selectedRoute.matchingEventBlueId())) {
            throw new InvalidExecutionEvidenceException(
                    "Selected managed route disagrees with accepted routed work",
                    ProcessorErrorCategory.InvalidContractBinding);
        }
        ContractBundle dispatch = selectedRoute.frozenDispatchBundle();
        if (dispatch == null) {
            throw new InvalidExecutionEvidenceException(
                    "Selected managed route lost its frozen dispatch surface",
                    ProcessorErrorCategory.InvalidContractBinding);
        }
        return dispatch;
    }

    private ContractBundle.ChannelBinding requireStepChannel(
            ContractBundle bundle,
            String channelKey) {
        if (channelKey == null || channelKey.isEmpty()) {
            throw new InvalidExecutionEvidenceException(
                    "Managed document-step work requires a Root channel key",
                    ProcessorErrorCategory.InvalidContractBinding);
        }
        ContractBundle.ChannelBinding channel =
                bundle != null ? bundle.channelBinding(channelKey) : null;
        if (channel == null) {
            throw new InvalidExecutionEvidenceException(
                    "Managed document-step channel is absent at /"
                            + channelKey,
                    ProcessorErrorCategory.InvalidContractBinding);
        }
        return channel;
    }

    private void requireStepChannelRole(
            ManagedDocumentWorkKind kind,
            ContractBundle.ChannelBinding channel) {
        ChannelContract contract = channel.contract();
        boolean valid;
        switch (kind) {
            case EXTERNAL_DELIVERY:
                valid = !ProcessorManagedChannelTypes.contains(contract);
                break;
            case DOCUMENT_UPDATE:
                valid = contract instanceof DocumentUpdateChannel;
                break;
            case TRIGGERED_EVENT:
                valid = contract instanceof TriggeredEventChannel;
                break;
            case EMBEDDED_EVENT:
                valid = contract instanceof EmbeddedNodeChannel
                        || contract instanceof EmbeddedCollectionEventChannel;
                break;
            case LIFECYCLE:
                valid = contract instanceof LifecycleChannel;
                break;
            default:
                valid = false;
                break;
        }
        if (!valid) {
            throw new InvalidExecutionEvidenceException(
                    "Managed document-step work kind " + kind
                            + " does not match Root channel "
                            + channel.key(),
                    ProcessorErrorCategory.InvalidContractBinding);
        }
    }

    private static List<DocumentUpdateOccurrence> updateOccurrences(
            List<DocumentUpdateData> updates,
            FrozenDispatchContext dispatchContext) {
        ContractBundle rootBundle = Objects.requireNonNull(
                dispatchContext, "dispatchContext")
                .bundle(JsonPointer.ROOT);
        List<DocumentUpdateOccurrence> exact =
                new ArrayList<DocumentUpdateOccurrence>(updates.size());
        for (DocumentUpdateData update : updates) {
            DocumentUpdateOccurrence occurrence = update.occurrence();
            exact.add(rootBundle == null
                    ? occurrence
                    : occurrence.withFrozenRootDispatchBundle(
                            rootBundle));
        }
        return Collections.unmodifiableList(exact);
    }

    private void initializeScope(String scopePath, boolean chargeScopeEntry, boolean finalizeAfterInitialization) {
        String normalizedScope = ProcessorEngine.normalizeScope(scopePath);
        Set<String> processedEmbedded = new LinkedHashSet<>();
        ContractBundle bundle = null;
        ScopeRuntimeContext scopeContext = runtime.scope(normalizedScope);
        if (JsonPointer.ROOT.equals(normalizedScope)) {
            runtime.setScopeEmbeddedDepth(normalizedScope, 0);
        }
        scopeContext.clearProcessedEmbeddedPaths();

        if (chargeScopeEntry) {
            runtime.chargeScopeEntry(normalizedScope);
        }

        try {
            if (runtime.hasTerminationMarker(normalizedScope)) {
                runtime.markScopeTerminatedFromMarker(normalizedScope);
                return;
            }
        } catch (IllegalStateException ex) {
            execution.abortRuntimeFailure(normalizedScope,
                    null,
                    ProcessorErrorCategory.InvalidReservedRuntimeState,
                    execution.fatalReason(ex, "Invalid terminated marker"));
            return;
        }

        while (true) {
            ProcessingObserver metrics = owner.observer();
            long resolvedStart = System.nanoTime();
            ResolvedScopeView scopeView;
            try {
                scopeView = runtime.scopeViewAt(normalizedScope);
            } finally {
                ProcessingObservations.record(
                        metrics,
                        ProcessingMetricId.BUNDLE_SCOPE_RESOLVED_LOOKUP_NANOS,
                        System.nanoTime() - resolvedStart);
            }
            if (scopeView == null || scopeView.resolved() == null) {
                return;
            }

            bundle = frameFactory.load(
                    scopeView,
                    normalizedScope,
                    metrics);
            participation.participate(normalizedScope, bundle);

            String childScope;
            try {
                childScope = frameFactory.nextEmbeddedChild(
                        normalizedScope, bundle, processedEmbedded);
            } catch (ProcessorEngine.BoundaryViolationException | IllegalArgumentException ex) {
                execution.abortRuntimeFailure(normalizedScope,
                        bundle,
                        ProcessorErrorCategory.PatchBoundaryViolation,
                        execution.fatalReason(ex, "Invalid embedded path"));
                return;
            }
            if (childScope == null) {
                break;
            }

            processedEmbedded.add(childScope);
            scopeContext.recordProcessedEmbeddedPath(childScope);
            runtime.attachScopeOccurrence(
                    normalizedScope,
                    childScope);
            runtime.setScopeEmbeddedDepth(childScope, runtime.scopeEmbeddedDepth(normalizedScope) + 1);
            try {
                runtime.validateProcessEmbeddedTraversalWithoutResolution(
                        childScope);
            } catch (ProcessorFailureException ex) {
                execution.abortRuntimeFailure(
                        normalizedScope,
                        bundle,
                        ex.errorCategory(),
                        execution.fatalReason(
                                ex,
                                "Invalid opaque embedded boundary"));
                return;
            }
            FrozenNode selectedChildNode = runtime.selectedFrozenAt(childScope);
            FrozenNode childNode = runtime.resolvedFrozenAt(childScope);
            if (childNode != null) {
                if (!frameFactory.isObjectScope(selectedChildNode)
                        || !frameFactory.isObjectScope(childNode)) {
                    execution.abortRuntimeFailure(normalizedScope,
                            bundle,
                            ProcessorErrorCategory.PatchBoundaryViolation,
                            "Embedded path " + childScope + " does not select an object scope");
                    return;
                }
                initializeScope(childScope, true, finalizeAfterInitialization);
            }
        }

        if (bundle == null) {
            return;
        }

        boolean initialized = runtime.hasInitializationMarker(normalizedScope);
        if (!initialized && finalizeAfterInitialization && bundle.hasCheckpoint()) {
            throw new IllegalStateException("Reserved key 'checkpoint' must not appear before initialization at scope " + normalizedScope);
        }

        if (initialized) {
            return;
        }

        runtime.chargeInitialization(normalizedScope);
        FrozenNode initialDocument;
        try {
            initialDocument =
                    runtime.capturePreInitializationScopeDocument(
                            normalizedScope);
        } catch (RuntimeException ex) {
            execution.abortRuntimeFailure(normalizedScope,
                    bundle,
                    ScopeIdentityErrorMapper.from(ex),
                    execution.fatalReason(
                            ex,
                            "Exact scope identity calculation failed"));
            return;
        }
        Node lifecycleEvent =
                ProcessorEngine.createLifecycleInitiatedEvent(
                        initialDocument);
        deliverLifecycle(normalizedScope, bundle, lifecycleEvent, false);
        if (finalizeAfterInitialization && !execution.shouldStopScopeWork(normalizedScope)) {
            propagationChain.drain();
        }
        if (!execution.shouldStopScopeWork(normalizedScope)) {
            lifecycleExecutor.publishInitializationMarker(
                    normalizedScope, initialDocument);
        }
    }

    /**
     * Executes one externally preselected occurrence without recursively
     * discovering unrelated channels or implicitly initializing the scope.
     */
    void processEvidenceDelivery(String scopePath,
                                 String channelKey,
                                 Node event) {
        String normalizedScope = ProcessorEngine.normalizeScope(scopePath);
        if (execution.shouldStopScopeWork(normalizedScope)) {
            return;
        }
        try {
            if (runtime.hasTerminationMarker(normalizedScope)) {
                runtime.markScopeTerminatedFromMarker(normalizedScope);
                return;
            }
        } catch (IllegalStateException ex) {
            execution.abortRuntimeFailure(
                    normalizedScope,
                    participation.bundle(normalizedScope),
                    ProcessorErrorCategory.InvalidReservedRuntimeState,
                    execution.fatalReason(ex, "Invalid terminated marker"));
            return;
        }
        ContractBundle bundle = participation.bundle(normalizedScope);
        if (bundle == null) {
            throw new InvalidExecutionEvidenceException(
                    "External delivery scope was not preflighted: "
                            + normalizedScope);
        }
        ContractBundle.ChannelBinding channel =
                bundle.channelBinding(channelKey);
        if (channel == null
                || ProcessorManagedChannelTypes.contains(
                channel.contract())) {
            throw new InvalidExecutionEvidenceException(
                    "External delivery occurrence is not executable at "
                            + normalizedScope + "/" + channelKey);
        }
        channelRunner.runExternalChannel(
                normalizedScope, bundle, channel, event);
        propagationChain.drain();
        channelRunner.persistPendingCheckpoints(normalizedScope);
    }

    ContractBundle externalClassificationBundle(
            String scopePath,
            String channelKey,
            boolean includeProcessEmbedded) {
        return externalClassificationBundle(
                scopePath,
                channelKey,
                includeProcessEmbedded,
                ExternalChannelDependencySnapshot.none());
    }

    ContractBundle externalClassificationBundle(
            String scopePath,
            String channelKey,
            boolean includeProcessEmbedded,
            ExternalChannelDependencySnapshot
                    declaredDependencies) {
        return candidateProjector.project(
                scopePath,
                channelKey,
                includeProcessEmbedded,
                declaredDependencies);
    }

    ChannelRunner.ExternalClassification classifyEvidenceDelivery(
            String scopePath,
            String channelKey,
            Node event,
            ContractBundle classificationBundle) {
        ContractBundle.ChannelBinding channel =
                candidateProjector.requireExternalSource(
                        scopePath, channelKey, classificationBundle);
        return channelRunner.classifyExternalChannel(
                ProcessorEngine.normalizeScope(scopePath),
                classificationBundle,
                channel,
                event);
    }

    void processClassifiedEvidenceDelivery(
            ChannelRunner.ExternalClassification classification) {
        if (classification == null) {
            return;
        }
        processClassifiedEvidenceDeliveryGroup(
                Collections.singletonList(classification));
    }

    void processClassifiedEvidenceDeliveryGroup(
            List<ChannelRunner.ExternalClassification>
                    classifications) {
        if (classifications == null
                || classifications.isEmpty()) {
            return;
        }
        ChannelRunner.ExternalClassification first =
                classifications.get(0);
        if (first == null || !first.acceptedNew()) {
            return;
        }
        String normalizedScope =
                ProcessorEngine.normalizeScope(
                        first.scopePath());
        if (execution.shouldStopScopeWork(normalizedScope)) {
            return;
        }
        ContractBundle bundle = participation.bundle(normalizedScope);
        if (bundle == null) {
            throw new InvalidExecutionEvidenceException(
                    "External delivery scope was not preflighted: "
                            + normalizedScope);
        }
        for (ChannelRunner.ExternalClassification classification
                : classifications) {
            if (classification == null
                    || !classification.acceptedNew()
                    || !normalizedScope.equals(
                    ProcessorEngine.normalizeScope(
                            classification.scopePath()))) {
                throw new InvalidExecutionEvidenceException(
                        "Logical delivery group changed before execution at "
                                + normalizedScope);
            }
            ContractBundle dispatchBundle =
                    classification.dispatchBundle();
            ContractBundle.ChannelBinding channel =
                    dispatchBundle.channelBinding(
                            classification.sourceChannelKey());
            if (channel == null
                    || ProcessorManagedChannelTypes
                    .contains(
                            channel.contract())) {
                throw new InvalidExecutionEvidenceException(
                        "External delivery occurrence changed before "
                                + "execution at "
                                + normalizedScope + "/"
                                + classification
                                .sourceChannelKey());
            }
        }
        ContractBundle checkpointBundle =
                channelRunner.runClassifiedExternalGroup(
                        classifications);
        propagationChain.drain();
        if (checkpointBundle != null
                && !execution.hasFailure()
                && execution.isScopeActive(
                normalizedScope)) {
            channelRunner.queueClassifiedCheckpoints(
                    classifications,
                    checkpointBundle);
        }
    }

    ContractBundle preflightEvidenceScope(String scopePath) {
        return preflightEvidenceScope(scopePath, true, true);
    }

    ContractBundle preflightEvidenceScopeAfterSelectedHeaders(
            String scopePath) {
        return preflightEvidenceScope(scopePath, false, true);
    }

    private ContractBundle preflightEvidenceScope(
            String scopePath,
            boolean preflightSelectedHeaders,
            boolean validateEmbeddedTraversal) {
        String normalizedScope = ProcessorEngine.normalizeScope(scopePath);
        if (validateEmbeddedTraversal) {
            runtime.validateProcessEmbeddedTraversalWithoutResolution(
                    normalizedScope);
        }
        FrozenNode selected = runtime.selectedFrozenAt(normalizedScope);
        try {
            /*
             * Classify directly present headers before effective resolution.
             * Otherwise an unknown direct type with no provider body is
             * misreported as malformed evidence rather than must-understand.
             */
            if (preflightSelectedHeaders) {
                owner.contractLoader().preflightSelectedContractHeaders(
                        selected);
            }
            FrozenNode resolved =
                    runtime.resolvedFrozenAt(normalizedScope);
            if (!frameFactory.isParticipatingScope(
                    normalizedScope, selected)
                    || !frameFactory.isParticipatingScope(
                    normalizedScope, resolved)) {
                throw new InvalidExecutionEvidenceException(
                        "Participating scope is absent or not an object: "
                                + normalizedScope);
            }
            if (runtime.hasTerminationMarker(normalizedScope)) {
                throw new InvalidExecutionEvidenceException(
                        "Participating scope is directly terminated: "
                                + normalizedScope);
            }
            return frameFactory.refresh(
                    normalizedScope,
                    false,
                    validateEmbeddedTraversal);
        } catch (InvalidExecutionEvidenceException exception) {
            throw exception;
        } catch (MustUnderstandFailureException exception) {
            /*
             * The feeder identifies the participating closure; support for
             * every effective contract in that closure is a processor
             * capability question, not malformed feeder evidence.
             */
            throw exception;
        } catch (RuntimeException exception) {
            if (ScopeIdentityErrorMapper.isProviderIdentityFailure(
                    exception)) {
                throw exception;
            }
            throw new InvalidExecutionEvidenceException(
                    "Participating scope preflight failed at "
                            + normalizedScope + ": "
                            + ProcessorEngine.deterministicMessage(
                            exception, "unsupported contract"));
        }
    }

    void preflightSelectedHeaders(String scopePath) {
        String normalizedScope =
                ProcessorEngine.normalizeScope(scopePath);
        owner.contractLoader().preflightSelectedContractHeaders(
                runtime.selectedFrozenAt(normalizedScope));
    }

    ContractBundle initializeEvidenceScope(String scopePath) {
        String normalizedScope = ProcessorEngine.normalizeScope(scopePath);
        if (execution.shouldStopScopeWork(normalizedScope)) {
            return null;
        }
        if (runtime.hasTerminationMarker(normalizedScope)) {
            runtime.markScopeTerminatedFromMarker(normalizedScope);
            return null;
        }
        ContractBundle bundle = participation.bundle(normalizedScope);
        if (bundle == null) {
            bundle = preflightEvidenceScope(normalizedScope);
        }
        if (runtime.hasInitializationMarker(normalizedScope)) {
            return bundle;
        }
        runtime.chargeInitialization(normalizedScope);
        FrozenNode initialDocument =
                runtime.capturePreInitializationScopeDocument(
                        normalizedScope);
        Node lifecycleEvent =
                ProcessorEngine.createLifecycleInitiatedEvent(
                        initialDocument);
        deliverLifecycle(normalizedScope, bundle, lifecycleEvent, false);
        if (execution.shouldStopScopeWork(normalizedScope)) {
            return null;
        }
        propagationChain.drain();
        if (execution.shouldStopScopeWork(normalizedScope)) {
            return null;
        }
        lifecycleExecutor.publishInitializationMarker(
                normalizedScope, initialDocument);
        return frameFactory.refresh(normalizedScope);
    }

    void handlePatch(String scopePath,
                     ContractBundle bundle,
                     JsonPatch patch,
                     boolean allowReservedMutation) {
        if (patch == null) {
            return;
        }
        handlePatches(scopePath,
                bundle,
                Collections.singletonList(patch),
                allowReservedMutation);
    }

    void handlePatches(String scopePath,
                       ContractBundle bundle,
                       List<JsonPatch> patches,
                       boolean allowReservedMutation) {
        handlePatches(scopePath, bundle, patches, allowReservedMutation, null);
    }

    void handlePatches(String scopePath,
                       ContractBundle bundle,
                       List<JsonPatch> patches,
                       boolean allowReservedMutation,
                       WorkingDocument.Preview preview) {
        handlePatchInputs(scopePath,
                bundle,
                PatchInput.mutableList(patches),
                allowReservedMutation,
                preview);
    }

    void handlePatchInputs(String scopePath,
                           ContractBundle bundle,
                           List<PatchInput> patches,
                           boolean allowReservedMutation,
                           WorkingDocument.Preview preview) {
        mutationExecutor.execute(
                scopePath,
                bundle,
                patches,
                allowReservedMutation,
                preview);
    }

    void deliverLifecycle(String scopePath,
                          ContractBundle bundle,
                          Node event,
                          boolean finalizeAfter) {
        lifecycleExecutor.deliver(scopePath, bundle, event);
    }

    void deliverTerminationLifecycle(String scopePath,
                                     ContractBundle bundle,
                                     Node event) {
        deliverLifecycle(scopePath, bundle, event, false);
    }

    void cleanupCheckpointState() {
        List<String> scopes = new ArrayList<>(
                participation.scopePaths());
        Collections.sort(scopes,
                (left, right) -> {
                    int depth = Integer.compare(
                            JsonPointer.split(right).size(),
                            JsonPointer.split(left).size());
                    return depth != 0
                            ? depth
                            : ExternalOrderKey.compareTextCodePoints(left, right);
                });
        for (String scopePath : scopes) {
            if (execution.shouldStopScopeWork(scopePath)) {
                continue;
            }
            ContractBundle bundle = frameFactory.refresh(scopePath);
            if (bundle != null) {
                channelRunner.cleanupInactiveCheckpoints(scopePath, bundle);
            }
        }
        channelRunner.persistAllPendingCheckpoints();
    }

    void requestInternalEventDrain() {
        propagationChain.requestDrain();
    }

    void drainInternalEvents() {
        propagationChain.drain();
    }
}
